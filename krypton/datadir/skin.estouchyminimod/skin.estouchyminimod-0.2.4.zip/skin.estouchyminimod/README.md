# EstouchyMiniMod

My modification of official skin Estouchy to make it more usable on smaller devices like smartphones.

## Change Log

- Enlarged list, thumbnail views
- Enlarged Notification dialog
- Enlarged Player OSD elements - progress bar/seek bar, title label, etc
- Enlarged Settings Dialog elements
